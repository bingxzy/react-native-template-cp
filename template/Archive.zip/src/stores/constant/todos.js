export const SET_TODO = 'SET_TODO';
export const FETCH_TODO_SYNC = 'FETCH_TODO_SYNC';
