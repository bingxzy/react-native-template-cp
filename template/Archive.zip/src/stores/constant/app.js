
// font size
export const CHANGE_FONT_SIZE = 'CHANGE_FONT_SIZE';

// language
export const CHANGE_LANGUAGE = 'CHANGE_LANGUAGE';
export const CHANGE_LANGUAGE_ASYNC = 'CHANGE_LANGUAGE_ASYNC';
