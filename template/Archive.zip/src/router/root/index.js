import appStack from './App';
import authStack from './Auth';

export default {
  appStack,
  authStack,
};
