// defult base w/h 375*975 iPhone XS
const guidelineBaseWidth = 375;
const guidelineBaseHeight = 812;
const scalingFactor = 1;
export default {
  guidelineBaseWidth,
  guidelineBaseHeight,
  scalingFactor,
};
