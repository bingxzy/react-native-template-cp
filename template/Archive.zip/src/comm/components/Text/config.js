export default {
  default: 0,
  large: 4,
  small: -2,
};
