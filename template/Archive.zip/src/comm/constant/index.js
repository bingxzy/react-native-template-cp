
export const THEME_ID = 'theme_id';

export const TOKEN = 'TOKEN';
