import Landing from './Landing';
import TodosList from './TodosList';
import TodosListRedux from './TodosListRedux';

export default {
  Landing,
  TodosList,
  TodosListRedux,
};
