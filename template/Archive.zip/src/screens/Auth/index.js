import AuthLoading from './AuthLoading';
import Login from './Login';

export default {
  AuthLoading,
  Login,
};
